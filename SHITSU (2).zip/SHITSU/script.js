function toggleDetails(detailId) {
    const details = document.getElementById(detailId);
    if (details) {
        // Toggle the display property
        if (details.style.display === "none" || details.style.display === "") {
            details.style.display = "block"; 
        } else {
            details.style.display = "none"; 
        }
    } else {
        console.error(`Element with ID "${detailId}" not found.`);
    }
}

function showAnswer(radioName, messageId, detailsId, correctAnswer) {
    const radios = document.getElementsByName(radioName);
    let selectedValue = "";
    
    // Check which radio button is selected
    for (const radio of radios) {
        if (radio.checked) {
            selectedValue = radio.value; 
            break;
        }
    }

    const message = document.getElementById(messageId);
    const details = document.getElementById(detailsId);

    if (message) {
        // Display the result message
        if (selectedValue === correctAnswer) {
            message.textContent = "Correct!";
        } else {
            message.textContent = "Incorrect. The correct answer is: " + correctAnswer;
        }
    } else {
        console.error(`Element with ID "${messageId}" not found.`);
    }

    if (details) {
        // Show the details section
        details.style.display = "block"; 
    } else {
        console.error(`Element with ID "${detailsId}" not found.`);
    }
}
